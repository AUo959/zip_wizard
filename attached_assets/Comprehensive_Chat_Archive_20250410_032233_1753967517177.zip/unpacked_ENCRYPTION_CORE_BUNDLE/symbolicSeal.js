
// symbolicSeal.js
const fs = require('fs');
const path = require('path');
const { encrypt, decrypt } = require('./crypto_refactored');

// Encrypt and save file
function sealFile(inputPath, outputPath) {
    const data = fs.readFileSync(inputPath, 'utf8');
    const { encryptedData, iv } = encrypt(data);
    const payload = { encryptedData, iv };
    fs.writeFileSync(outputPath, JSON.stringify(payload, null, 2));
    console.log(`File sealed: ${outputPath}`);
}

// Decrypt and restore file
function unsealFile(inputPath, outputPath) {
    const payload = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
    const plainText = decrypt(payload.encryptedData, payload.iv);
    fs.writeFileSync(outputPath, plainText);
    console.log(`File unsealed: ${outputPath}`);
}

// CLI support
if (require.main === module) {
    const [,, mode, input, output] = process.argv;
    if (!mode || !input || !output) {
        console.log("Usage:
  node symbolicSeal.js seal <in> <out>
  node symbolicSeal.js unseal <in> <out>");
        process.exit(1);
    }
    if (mode === 'seal') {
        sealFile(input, output);
    } else if (mode === 'unseal') {
        unsealFile(input, output);
    } else {
        console.log("Mode must be 'seal' or 'unseal'");
    }
}
